<div style="text-align: center;border:1px solid #333;padding:1vw">
	<?php echo "This is the all service block with owl slider"; ?>
</div>

