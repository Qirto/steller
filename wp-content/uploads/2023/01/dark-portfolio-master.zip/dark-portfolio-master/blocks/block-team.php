

<div class="team-member">
    <img src="<?php block_field( 'team-member-image' ); ?>" width="800"  alt="<?php block_field( 'team-member-name' ); ?><">
    <div class="team-member-details">
        <h4><?php block_field( 'team-member-name' ); ?></h4>
        <p><?php block_field( 'team-member-position' ); ?></p>
        <!--
        <p class="social-links">
            <a href="#" class="social-link saulticon">facebook</a>
            <a href="#" class="social-link saulticon">twitter</a>
            <a href="#" class="social-link saulticon">linkedin</a>
        </p>
        !-->
    </div>
</div>
