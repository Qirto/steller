<div class="box dark-bg text-center" style="background-color:#14171a;margin-bottom:15vh;padding:5vw">
	<h3 title="<?php echo block_field('title');?>">
		<a href="<?php get_permalink(get_the_ID());?>">
			<?php echo block_field('title');?>
		</a>
	</h3>
    <script type="text/javascript" src="//lzomarketing.com/form/generate.js?id=<?php echo block_field('mautic-form-number');?>"></script>
</div>
