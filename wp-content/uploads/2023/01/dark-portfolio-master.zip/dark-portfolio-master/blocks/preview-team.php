<?php

echo block_value('team-member-name');

?>
