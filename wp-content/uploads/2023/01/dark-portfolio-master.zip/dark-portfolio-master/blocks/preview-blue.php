<?php

echo block_value('title');

?>
