Dark Portfolio
================

A lightweight WordPress Development Theme for custom website development (very loosely) based on _s.

Underscores is a fantastic starter theme for submitting themes to the WP.org repo, but I find it a bit bloated for client work. 

This starter theme doesn't have any bells and whistle and is super simple.

It uses Sass, so you'll need to have that set up, but once you do, it's very easy to get going.

To use this theme, rename the folder, change the comment in the style.css and make it your own.

This theme is distributed under the wtfpl license - http://www.wtfpl.net/




